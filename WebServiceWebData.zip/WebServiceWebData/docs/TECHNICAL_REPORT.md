# Technical Report: Book Library and Analytics API

**Module:** XJCO3011 Web Services and Web Data  
**Assignment:** Coursework 1 - Individual Web Services API Development Project  
**Author:** [Your Name]  
**Student ID:** [Your ID]  
**Repository:** [Public GitHub URL - add before submission]  
**Date:** April 2026  

**Note on length:** The module brief limits the submitted technical report to **five pages**. This document is intentionally detailed so you can **select and condense** the sections most relevant to your oral examination, or export with smaller margins or font if your school allows. Remove lower-priority subsections if the PDF exceeds the limit.

---

## Abstract

This report describes the design and implementation of a **RESTful HTTP API** backed by a **relational SQL database**. The primary resource is a **Book** entity supporting full **CRUD** semantics, with additional **read-only analytics** endpoints that aggregate catalogue data by genre. The stack comprises **Python 3**, **FastAPI**, **SQLAlchemy 2.x**, **SQLite**, and **Uvicorn**. A **CSV-based** bibliographic sample dataset can be bulk-imported to demonstrate integration with file-oriented public data. The submission includes **automated tests**, **API documentation** (OpenAPI and a static PDF), and reflection on **security**, **limitations**, and **Generative AI (GenAI)** use in line with the module's Green assessment policy.

---

## 1. Introduction

### 1.1 Problem and scope

University coursework and small organisations often need a **minimal, inspectable** backend that stores structured records and exposes them to clients (web apps, scripts, or integration tests) without committing to a heavyweight enterprise framework. This project addresses that need using a **book catalogue** as the domain: titles, authors, genres, and optional ratings support both **transactional** workflows (librarians or admins maintaining records) and **analytical** questions (how genres compare by average rating or volume).

The **scope** is deliberately API-centric: there is no bespoke HTML front-end beyond a small landing page; clients are expected to consume **JSON** over HTTP. This aligns with the module emphasis on **web services** and **web data** rather than full-stack UI development.

### 1.2 Objectives

1. Persist at least one logical **data model** in an **SQL** database with verifiable **Create, Read, Update, Delete** operations.  
2. Expose **multiple HTTP endpoints** with **JSON** payloads and **conventional status codes**.  
3. Integrate **external or file-based data** (CSV) with clear **provenance** and academic-use awareness.  
4. Provide **documentation** suitable for developers and examiners (OpenAPI + PDF).  
5. Demonstrate **software engineering discipline**: tests, configuration separation, and explicit discussion of **trade-offs** and **GenAI** use.

---

## 2. Requirements traceability (coursework brief)

| Brief requirement | Evidence in this project |
|-------------------|---------------------------|
| At least one model with full CRUD linked to a database | ORM model `Book` mapped to table `books`; `POST`, `GET`, `PATCH`, `DELETE` on `/api/v1/books/` |
| At least four HTTP-accessible endpoints | Books collection, book by id, analytics summary, health, plus mutating routes (total exceeds four) |
| JSON request/response (other formats justified in report) | Pydantic v2 schemas; `application/json` throughout; no alternate wire format used |
| Correct status and error codes | 200, 201, 204, 401, 404, 422 used consistently (see Section 6) |
| SQL database | SQLite default; `DATABASE_URL` allows PostgreSQL or other SQLAlchemy-supported backends |
| Public data and citation | `data/books_gutenberg_catalog_sample.csv` (from [Project Gutenberg catalog feed](https://www.gutenberg.org/cache/epub/feeds/pg_catalog.csv)), `data/DATA_PROVENANCE.txt`; may be replaced with other openly licensed CSVs if column mapping is adjusted |
| Demonstration via local run, hosting, or MCP | Local **Uvicorn**; same ASGI app deployable to **PythonAnywhere**; MCP not implemented (optional in brief) |
| REST or GraphQL with rationale if GraphQL | **REST** chosen; rationale in Section 5.3 |
| Technology choice justified | Section 5 |

---

## 3. System architecture

### 3.1 High-level view

The system has three conceptual tiers:

1. **Client layer:** HTTP user agents (browser calling Swagger UI, `curl`, Python `httpx`, or future mobile apps).  
2. **Application layer:** FastAPI application (`app/main.py`) registering routes, middleware-style dependencies, and exception handlers.  
3. **Persistence layer:** SQLAlchemy engine and session factory targeting a single SQLite file (`books.db`) by default.

**Request path (read example):** Client sends `GET /api/v1/books/{id}` - FastAPI matches route - dependency `get_db()` yields a database session - CRUD function loads the row by primary key - Pydantic schema serialises the result - JSON response with status **200**, or **404** if missing.

**Request path (write example):** Client sends `POST /api/v1/books/` with JSON body and `X-API-Key` - dependency `verify_api_key()` runs first - on success, validated body becomes a `BookCreate` schema - CRUD inserts a row and commits - **201** with serialised `BookRead`.

### 3.2 Module structure (logical layers)

| Package / module | Responsibility |
| `app/main.py` | Application factory, lifespan (schema creation on startup), global validation error handler, HTML landing page for `/`. |
| `app/config.py` | `pydantic-settings` for `DATABASE_URL`, `API_KEY`, `DISABLE_AUTH`. |
| `app/database.py` | Engine, `SessionLocal`, `get_db()` generator for FastAPI dependencies, `init_db()`. |
| `app/models.py` | SQLAlchemy declarative `Book` model. |
| `app/schemas.py` | Input/output contracts: `BookCreate`, `BookUpdate`, `BookRead`, analytics DTOs. |
| `app/crud.py` | Database operations and analytics SQL (`func.count()`, `func.avg()`, `group_by()`). |
| `app/deps.py` | `Annotated` dependencies: DB session, optional auth. |
| `app/routers/books.py` | Book routes. |
| `app/routers/analytics.py` | Analytics routes. |
| `scripts/import_csv.py` | Offline ETL from CSV to database. |

This separation supports **unit testing** (CRUD with injected session) and **integration testing** (full app with overridden `get_db()`).

### 3.3 API versioning

Routes are prefixed with **`/api/v1`**. This reserves the path space for a future **`v2`** without breaking existing clients, which is a common industry practice for public APIs.

---

## 4. Data model and database design

### 4.1 Table: `books`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | INTEGER | Primary key, autoincrement | Stable identifier for REST URLs |
| `title` | VARCHAR(500) | NOT NULL, indexed | Search and display |
| `author` | VARCHAR(300) | NOT NULL, indexed | Filtering and attribution |
| `genre` | VARCHAR(120) | NOT NULL, indexed | Analytics grouping |
| `publication_year` | INTEGER | NULL allowed | Optional metadata |
| `rating` | FLOAT | NULL allowed | User or imported score (0-5 in validation) |
| `notes` | TEXT | NULL allowed | Free-text annotation |

**Normalisation:** For this coursework scope, a **single table** is sufficient. A production system might split **authors** and **genres** into separate tables with many-to-many relationships; that would complicate CRUD without adding marks for the stated minimum requirements.

### 4.2 SQLite vs other SQL engines

**SQLite** minimises operational overhead (no separate DB server process, single file artefact). It is adequate for development, demos, and low-concurrency workloads. The connection string is externalised via **`DATABASE_URL`**, so migration to **PostgreSQL** (for example on PythonAnywhere or Heroku) is primarily a configuration change plus any dialect-specific types, which SQLAlchemy abstracts in most cases.

**Known SQLite caveat:** Concurrent writers are limited; the brief does not require high throughput, but this is noted under limitations.

---

## 5. REST API design and rationale

### 5.1 Resource naming

Books are modelled as **`/api/v1/books/`** (collection) and **`/api/v1/books/{book_id}`** (instance). This follows **REST** conventions: nouns for resources, HTTP verbs for intent (`POST` create, `GET` read, `PATCH` partial update, `DELETE` remove).

### 5.2 Why REST instead of GraphQL

**GraphQL** excels when clients need **flexible, nested queries** over a graph of related types and wish to avoid over-fetching. Here, the domain is a **single primary resource** with one analytics aggregate endpoint. **OpenAPI-first REST** gives automatic **Swagger UI** for examiners, straightforward **status code** mapping, and simpler **caching** semantics for GET requests. A GraphQL layer would add resolver complexity and schema maintenance without proportional benefit for this problem size. If the domain were expanded to authors, publishers, reviews, and cross-entity traversals, GraphQL would merit re-evaluation.

### 5.3 HTTP semantics and idempotency

- **`GET`** and **`DELETE`** are **idempotent** in intent (repeating DELETE on a missing id yields 404 consistently).  
- **`POST /books/`** creates a **new** row each time (not idempotent without client-generated ids).  
- **`PATCH`** applies partial updates; validation ensures types and ranges (e.g. rating 0-5).

### 5.4 Pagination and filtering

`GET /api/v1/books/` accepts **`skip`** and **`limit`** (capped at 100) and optional **`genre`**. This is **offset-based pagination**, simple but less ideal than **cursor-based** pagination for huge tables (future work).

---

## 6. Status codes, errors, and validation

| Code | When used |
|------|-----------|
| 200 | Successful GET or PATCH with body |
| 201 | Successful POST creating a resource |
| 204 | Successful DELETE (no body) |
| 401 | Missing or wrong `X-API-Key` on protected routes |
| 404 | Book id not found |
| 422 | Pydantic validation failure (wrong types, out-of-range values) |

The global handler for **`RequestValidationError`** returns JSON of the form `{"detail": [...], "code": "validation_error"}` so clients can distinguish validation failures from **404** not-found cases.

---

## 7. Security model

### 7.1 API key authentication

Mutating operations require header **`X-API-Key`**. The key is compared to a value loaded from the environment (`API_KEY`). This is **not** multi-tenant user authentication; it is a **shared secret** suitable for coursework and private demos.

**Threat model (simplified):** The key protects against **casual** writes on exposed demo hosts. It does **not** provide non-repudiation, rotation policies, or per-client revocation.

### 7.2 Configuration and secrets

Secrets must not be committed to Git. The repository ships **`.env.example`** only; real keys live in **`.env`** (gitignored).

### 7.3 Transport

Local development uses **HTTP**. Production deployments should terminate **TLS** at the platform reverse proxy (PythonAnywhere, nginx, etc.).

---

## 8. Data pipeline: CSV import

The file **`data/books_gutenberg_catalog_sample.csv`** uses columns: `title`, `author`, `genre`, `publication_year`, `rating`, `notes`. It is a filtered subset of the Project Gutenberg catalog CSV; regenerate via **`scripts/build_gutenberg_csv.py`**. The script **`scripts/import_csv.py`**:

1. Initialises the schema via `init_db()`.  
2. Optionally **`DELETE`**s all rows (`--replace`) for a clean load.  
3. Parses CSV with UTF-8-sig support for Excel compatibility.  
4. Maps each row to **`BookCreate`** and reuses the same **`create_book()`** path as the HTTP API, ensuring **one validation logic** for both interactive and batch ingress.

**Licencing:** Gutenberg catalog metadata is used under Project Gutenberg’s stated terms (see `data/DATA_PROVENANCE.txt` and https://www.gutenberg.org/policy/license.html). The bundled CSV contains no full book text. Any replacement dataset must document **licence** and **attribution** (Section 2, brief).

---

## 9. Testing strategy

### 9.1 Automated tests (`tests/`)

| Test module | What it asserts |
|-------------|-----------------|
| `test_api.py` | Health; full CRUD sequence; analytics shape; 422 validation envelope |
| `test_auth.py` | 401 without key; 201 with correct key when auth enabled |

### 9.2 Isolation technique

Tests **override** the FastAPI `get_db()` dependency with a **SQLite in-memory** engine (`StaticPool`) and call `create_all()` on the metadata. This avoids mutating the developer's **`books.db`** file and keeps tests **deterministic**.

### 9.3 What is not covered

Load testing, fuzzing, and formal verification are **out of scope**. There is no coverage target mandated by the brief; additional tests could cover edge cases (e.g. extremely long titles hitting VARCHAR limits).

---

## 10. Deployment and operations

### 10.1 Local execution

```text
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

`--reload` is useful in development; production should use a process manager.

### 10.2 Hosted deployment (e.g. PythonAnywhere)

The application is a standard **ASGI** app (`app.main:app`). Hosting steps typically include: upload code, install dependencies, set **environment variables**, configure **static URL** to the WSGI/ASGI entrypoint, and ensure **`DATABASE_URL`** points to a persistent path or managed PostgreSQL.

### 10.3 Observability

Structured logging and metrics are **not** implemented; debugging relies on Uvicorn console output and FastAPI's default tracebacks in development.

---

## 11. Evaluation and lessons learned

**Strengths:** Clear separation of concerns; OpenAPI documentation generated from code; tests protect regressions; CSV import demonstrates **web data** ingestion beyond hand-entered JSON.

**Weaknesses:** Single API key; SQLite concurrency; analytics are SQL-only aggregates without time-series or caching.

**Lessons:** Early investment in **dependency injection** for the database session paid off for testing. Environment-specific issues (Windows proxies, Python 3.8 typing) consumed time that documentation in `README.md` now reduces for future runs.

---

## 12. Limitations and future work

| Limitation | Possible extension |
|------------|-------------------|
| Global API key | OAuth2 password flow or API keys per client in DB |
| SQLite write concurrency | PostgreSQL + connection pooling |
| Offset pagination | Cursor-based `?after_id=` |
| Single aggregate analytics | Precomputed materialised views or batch jobs |
| No MCP server | Thin MCP wrapper exposing the same CRUD as tools for LLM clients (brief optional) |

---

## 13. Generative AI (GenAI) declaration

**Policy:** This module uses a **Green** GenAI policy: tools must be **declared**; undeclared use is **academic misconduct**. Higher grades reward thoughtful, creative use with logs attached.

| Tool (edit for your case) | Purpose |
|----------------------------|---------|
| [e.g. Cursor / GitHub Copilot / ChatGPT] | [e.g. scaffolding FastAPI routes, drafting README, debugging import errors] |

**Declaration:** I attest that the above table is accurate to the best of my knowledge. I attach **exported conversation excerpts** as required by the brief.

**Personal reflection (required):** [Write 3-5 sentences: what you asked GenAI to do, what you verified manually (tests, Swagger, code reading), and one limitation you noticed in generated code.]

---

## 14. Conclusion

The delivered system meets the module's **minimum technical requirements** for a **SQL-backed**, **JSON**, **REST** API with **CRUD**, **documentation**, and **tests**, while grounding the implementation in **justified** technology choices and an explicit **data** path from **CSV** to database. Remaining gaps (enterprise security, scale-out) are acknowledged and mapped to credible **future work**, consistent with the scope of a single coursework submission.

---

## References

1. FastAPI Documentation. https://fastapi.tiangolo.com/  
2. Pydantic Documentation. https://docs.pydantic.dev/  
3. SQLAlchemy Documentation. https://docs.sqlalchemy.org/  
4. Fielding, R. T. (2000). *Architectural Styles and the Design of Network-based Software Architectures* (REST dissertation). UC Irvine.  
5. Richardson, L., & Ruby, S. (2013). *RESTful Web APIs*. O'Reilly.  
6. Open Library. https://openlibrary.org/  
7. University of Leeds (2025/2026). *XJCO3011 Coursework 1 Brief*. Minerva.  
8. Python Software Foundation. *Python typing and typing_extensions* (for `Annotated` on Python 3.8). https://docs.python.org/3/library/typing.html  

---

*End of report. Trim sections or tighten prose if the PDF exceeds five pages.*
