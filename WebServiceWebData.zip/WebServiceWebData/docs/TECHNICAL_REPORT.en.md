Technical Report: Book Library and Analytics API

Author: TBD
Student ID: TBD
Repository: TBD public repository URL
Date: April 2026

1. Introduction

This project implements a RESTful HTTP backend centred on a book catalogue: relational SQL persistence for bibliographic fields, full CRUD on Book resources, read-only analytics aggregated by genre, plus health checks and OpenAPI documentation. Interaction is primarily JSON; the root path only serves a minimal landing page for Swagger. The following sections cover architecture and key design choices, rationale for the technology stack, data and API semantics, security and data ingestion, deployment, testing and lessons learned, limitations and improvements, and a generative-AI declaration with reflective analysis.

2. Architecture and Key Design Choices

The system follows a classic three-tier pattern: clients reach FastAPI routes over HTTP; the application layer obtains database sessions via dependency injection and calls crud; persistence uses SQLAlchemy Session with SQLite or another engine pointed to by DATABASE_URL. Routers are split by responsibility into books and analytics APIRouters, mounted under /api/v1 in main, matching versioned URLs and allowing future evolution without breaking existing clients.

Module layout: main.py handles lifespan and global exception handling; config.py centralises Settings; database.py provides the engine, session factory, and get_db(); models and schemas separate ORM from Pydantic contracts; crud.py stays independent of FastAPI for easier testing; deps.py wraps auth and DB dependencies as reusable Annotated aliases; routers only orchestrate HTTP semantics. This keeps contract, persistence, and transport boundaries clear and reflects a maintainability-first choice.

Request flow: reads inject a session via get_db(), query the ORM, and serialise to BookRead; writes run verify_api_key() when auth is enabled, validate BookCreate or BookUpdate, then commit; the analytics endpoint is read-only and needs no API key, with aggregation in analytics_summary() (in the crud module). A single RequestValidationError handler returns JSON including a code field, distinct from business 404 responses.

The domain is a single primary resource plus aggregate read-only endpoints—no multi-entity graph traversal or client-driven field shaping—so REST and OpenAPI are preferred over GraphQL. Resource paths use nouns and standard HTTP verbs, aligned with idempotency and pagination semantics in Section 4.

3. Technology Stack Rationale: Language, Framework, and Database

3.1 Programming language: Python 3

Python was chosen because coursework and demos call for fast iteration and readable source; its ecosystem fits small services; FastAPI, SQLAlchemy, Pydantic, and pytest integrate in one stack, reducing cross-language friction; type hints and typing_extensions.Annotated make dependency injection and route signatures traceable in the IDE, balancing development speed with some maintainability. Alternatives such as Node.js or Java were not selected here due to timeline and local-environment consistency, not because they are unsuitable.

3.2 Application framework and contracts: FastAPI, Pydantic, Uvicorn

FastAPI supports the goal of a REST API with auto-generated documentation: routes and dependencies are declared with types; OpenAPI is exposed at /docs and /redoc, limiting drift from hand-written docs. Pydantic v2 models request and response bodies and settings, aligning BookCreate with column lengths to block invalid writes at the boundary. pydantic-settings loads DATABASE_URL, API_KEY, and DISABLE_AUTH from .env, separating config from code.

Uvicorn runs the ASGI app. For local development run uvicorn app.main:app --reload --host 127.0.0.1 --port 8000 (auto-reload on save; omit the --reload flag if hot reload is not needed). requirements.txt lists only the minimal uvicorn dependency, not the variant that also installs optional performance extras. On Windows those extras often lack prebuilt wheels, so pip may try to compile from source and fail without a C toolchain such as MSVC. Keeping the minimal install reduces pip failures for classmates on the same platform.

3.3 Persistence: SQLAlchemy 2.x with SQLite as default

SQLAlchemy 2.x uses declarative models and 2.0-style select() so CRUD and analytics share one Session abstraction; aggregations use func.count(), func.avg(), and group_by() in the database instead of pulling full tables into Python.

By default SQLite stores data in a single books.db file with no separate database daemon, which simplifies submission and classroom demos; DATABASE_URL externalises the connection string so switching to PostgreSQL mostly keeps business SQL under SQLAlchemy, with attention to dialect and type details. This trades operational simplicity for known limits on concurrent writes and locking; it is acceptable when reads dominate and concurrency is modest. If write load or data volume grows, a server-grade database, connection pooling, and formal migrations are appropriate. The app uses create_all() without Alembic, which matches low schema-churn expectations here, though versioned migrations should be added for long-running production use.

Tests use pytest and Starlette TestClient with in-memory SQLite and dependency_overrides so regressions do not touch the developer’s books.db. httpx is pulled in as a test dependency.

4. Data Model and API Semantics

4.1 Table structure and columns

The persistent entity maps to SQL table books and ORM class app.models.Book. SQLAlchemy declarative columns align with Pydantic BookCreate, BookUpdate, and BookRead: string fields use min_length and max_length matching VARCHAR widths; optional columns allow NULL in the database and may be omitted or null in JSON; rating uses AVG in analytics with NULL rows excluded from the average so “unrated” is not treated as zero.

Column definitions and contract mapping for table books:

| Column | SQL type | Constraints / indexes | API and validation notes |
|--------|----------|------------------------|---------------------------|
| id | INTEGER | Primary key, autoincrement; indexed in ORM | Only on BookRead; generated by DB; not in POST body |
| title | VARCHAR(500) | NOT NULL, indexed | Required; length 1–500; main list/display field |
| author | VARCHAR(300) | NOT NULL, indexed | Required; length 1–300 |
| genre | VARCHAR(120) | NOT NULL, indexed | Required; length 1–120; list filter by exact genre; analytics group_by() |
| publication_year | INTEGER | Nullable | Optional; validated 1000–2100; not in current aggregate SQL |
| rating | FLOAT | Nullable | Optional; 0–5 inclusive; AVG excludes NULL in aggregates |
| notes | TEXT | Nullable | Optional; no max length in Pydantic; long free text |

Primary key id backs REST path /api/v1/books/{id} and default list ordering. title, author, and genre are indexed to support genre filtering and frequent reads; denormalising author and genre as strings in one table reduces CRUD and CSV import complexity—a deliberate trade-off, with normalisation possible later if author tables or controlled vocabularies are needed.

4.2 REST choice and semantics

The domain is a single Book resource plus read-only genre aggregates—no multi-hop graph queries—so REST and FastAPI-generated OpenAPI suit Swagger-based integration and contract checks; GraphQL was not adopted to avoid resolver and schema overhead at this scale. GET and DELETE are idempotent in intent; DELETE on an already removed id returns 404 without affecting other rows. POST creates a new row each time; duplicate submissions can duplicate rows unless idempotency keys are added. PATCH uses model_dump() with exclude_unset and only updates fields present in the JSON, which fits partial updates such as rating or notes alone.

4.3 Pagination, filtering, and status codes

GET /api/v1/books/ supports skip, limit, and optional exact genre match; limit is capped at 100; crud orders by id for stable ordering. Offset pagination is used; deep pages or heavy concurrent writes may motivate cursor-based pagination, as noted in Section 8. HTTP status codes include 200, 201, 204, 401, 404, and 422; validation failures include validation_error to distinguish them from 404.

5. Security, Configuration, and Data Ingestion

Mutating endpoints use a shared-secret X-API-Key checked against API_KEY; DISABLE_AUTH can disable this in tests. The model fits demos and single-team use, not multi-tenant revocation. Secrets live in .env; the repo ships .env.example. Public deployments should terminate HTTPS at the platform.

CSV import runs via scripts/import_csv.py, reusing BookCreate and create_book() for the same rules as HTTP; UTF-8-sig and --replace are supported. External datasets should document provenance and licence in DATA_PROVENANCE.txt or equivalent.

6. Deployment and Operations

Local start:

uvicorn app.main:app --host 127.0.0.1 --port 8000

Production should use a process manager. Hosting requires ASGI entry, environment variables, and a persistent DATABASE_URL. Structured logging and metrics are not implemented; troubleshooting relies on console output and dev tracebacks; production could add request IDs and health checks.

7. Testing, Challenges, and Lessons Learned

7.1 Test approach and coverage

test_api.py covers health, full CRUD, analytics JSON shape, validation envelope, length and numeric bounds, genre filtering, and limit overflow; test_auth.py uses a separate fixture with auth enabled to assert 401 without a key and 201 with the correct key. conftest uses in-memory SQLite, StaticPool, overridden get_db(), and clears dependency_overrides and get_settings() cache to avoid polluting local books.db or cross-test state.

Not in scope here: load tests, fuzzing, security penetration, or SQLite contention under multi-process stress; high-traffic launches should plan these separately.

7.2 Challenges during development

First, pydantic-settings uses lru_cache(): tests must call cache_clear() when only environment variables change, or auth toggles appear inconsistent—teardown in conftest clears this explicitly. Second, some optional uvicorn extras on Windows can require compilation; pinning the standard uvicorn package avoids that. Third, boundary cases such as overlong titles were initially checked manually in Swagger; automated tests now cover Pydantic and Query() together.

7.3 Lessons learned

Centralising DB access in crud and keeping routers thin lets TestClient integration tests and potential Session-level unit tests share logic; the import script reuses create_book() to avoid divergent rules. Treating OpenAPI as the contract early helps align graders or frontends. Dependency overrides for tests are, at this scale, a cost-effective isolation mechanism.

8. Limitations and Potential Future Improvements

Authorisation remains a global API key; OAuth2 or per-client keys stored and revocable in a database are future options. Under write concurrency and growth, migrate to PostgreSQL with pooling, backups, and Alembic-style migrations. Analytics could move from live aggregates to materialised views or caches. Pagination can evolve from offset to cursors; search can extend beyond exact genre to full-text or dedicated search engines. Richer domains may warrant GraphQL or MCP-style tooling. Observability should move from console logs to structured logging and alerting.

9. Generative AI: Declaration and Reflective Analysis

9.1 Compliance declaration and tool log

If the course or institution requires disclosure of generative-AI use, list tools and purposes truthfully and retain conversation excerpts as required. The declaration must attest accuracy. Placeholders to complete: tool names, main use categories, and whether use was for code, documentation, or debugging.

9.2 Thoughtful use of generative tools

Generative tools are treated as assistants: useful for scaffolding, explaining stack traces, and structuring documents, but not a substitute for judging test pass/fail. Generated output should be runnable and testable; run pytest locally, exercise Swagger, and read critical paths before submission. Risks include style or version mismatch with the project, missed edge cases, and hallucinated API usage. Mitigations include pinned dependencies, small incremental changes, and treating tests and OpenAPI as the source of truth. If undisclosed generative use is academic misconduct, disclosure and audit trails are mandatory; reflecting which decisions you made versus what you verified after a suggestion matters more than listing tool names alone.

9.3 Personal reflection (to complete)

TBD: tools actually used; tasks requested; verification steps you performed; one limitation or correction observed in generated output.

10. Conclusion

The project delivers a testable book-library API with clear layering and explicit contracts, using Python, FastAPI, SQLAlchemy, and SQLite by default, with personal rationale for language, framework, and database choices. Testing and dependency-injection practices support iteration and regression; Section 8 summarises limitations and improvements. Generative AI should be used under disclosure with local verification and academic integrity as constraints.

References

1. FastAPI Documentation. https://fastapi.tiangolo.com/
2. Pydantic Documentation. https://docs.pydantic.dev/
3. SQLAlchemy Documentation. https://docs.sqlalchemy.org/
4. Fielding, R. T. (2000). Architectural Styles and the Design of Network-based Software Architectures. Doctoral dissertation, UC Irvine.
5. Richardson, L., & Ruby, S. (2013). RESTful Web APIs. O’Reilly.
6. Open Library. https://openlibrary.org/

— End of report —
