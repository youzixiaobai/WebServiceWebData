图书库与分析 API 说明

本项目提供基于 SQL 持久化的图书目录服务：图书资源的增删改查，以及按体裁 genre 分组的只读统计。对外路径统一挂在 /api/v1 下，请求与响应体为 JSON（UTF-8），带请求体时 Content-Type 为 application/json。本地默认服务地址 http://127.0.0.1:8000。针对所有图书这一组接口，地址是 /api/v1/books/。针对特定的一本书，在斜杠后写编号，例如 /api/v1/books/3 表示 id 为 3 的那一条。

版本：1.0.0


1. 鉴权

凡是会新建、修改或删除图书记录的请求，都须在请求头携带 X-API-Key，取值与运行环境中的 API_KEY 一致，详见 .env.example。对应三条路径与动词：POST /api/v1/books/（新建）、PATCH /api/v1/books/{book_id}（改）、DELETE /api/v1/books/{book_id}（删）。

以下接口只读取数据，调用时不必携带密钥：GET /health、GET /api/v1/books/、GET /api/v1/books/{book_id}、GET /api/v1/analytics/summary。

将 DISABLE_AUTH 设为 true 时跳过密钥校验，仅用于本地调试，勿用于对外部署。

密钥错误或缺失时返回 401，响应体含 detail 说明，响应头含 WWW-Authenticate: ApiKey。


2. HTTP 状态码

| 状态码 | 含义 |
|--------|------|
| 200 | 成功（查询或更新成功） |
| 201 | 已创建（新建图书） |
| 204 | 无内容（删除成功，无响应体） |
| 401 | 未授权 |
| 404 | 资源不存在（如图书 id 不存在） |
| 422 | 请求参数或 JSON 未通过校验 |


3. 错误响应示例

校验失败（422）时除 detail 为字段错误列表外，固定附带 code：

{
  "detail": [ ],
  "code": "validation_error"
}

图书不存在（404）：

{
  "detail": "Book not found"
}

未授权（401）：

{
  "detail": "Invalid or missing API key. Send header X-API-Key."
}


4. 图书 JSON 结构

列表、单条查询、创建成功、更新成功均返回同一形状（BookRead）。创建请求体（BookCreate）字段相同但不包含 id，其中 title、author、genre 必填，其余可选。更新（BookUpdate）各字段均可选，仅提交的字段会写入，其余保持原值。

| 字段 | 类型 | 说明 |
|------|------|------|
| id | 整数 | 仅响应中有，数据库自增 |
| title | 字符串 | 必填（创建时）；长度 1～500 |
| author | 字符串 | 必填（创建时）；长度 1～300 |
| genre | 字符串 | 必填（创建时）；长度 1～120；列表可按其精确筛选；统计按该字段分组 |
| publication_year | 整数或 null | 可选；若给出则 1000～2100 |
| rating | 数值或 null | 可选；若给出则 0～5（含端点） |
| notes | 字符串或 null | 可选 |

创建示例：

{
  "title": "Example",
  "author": "A. Student",
  "genre": "Fiction",
  "publication_year": 2020,
  "rating": 4.0,
  "notes": null
}


5. 分析汇总 JSON（GET /api/v1/analytics/summary 的 200 响应体）

| 字段 | 类型 | 含义 |
|------|------|------|
| total_books | 整数 | 当前 books 表行数 |
| genres | 数组 | 每个不同 genre 一条 |
| genres[].genre | 字符串 | 体裁名 |
| genres[].count | 整数 | 该体裁下图书本数 |
| genres[].average_rating | 数值或 null | 该体裁下有评分时的平均值，无非空评分时为 null |
| average_rating_overall | 数值或 null | 全表非空评分的平均值，无非空评分时为 null |


6. 接口一览

GET /health  
无鉴权。200 响应体：{ "status": "ok" }

GET /api/v1/books/  
无鉴权。查询参数：skip（默认 0，≥0）、limit（默认 50，1～100）、genre（可选，按 genre 列精确匹配）。成功时状态码为 200，响应体是图书数组的 JSON，数组中每一项是一条完整记录，按 id 排序。

GET /api/v1/books/{book_id}  
无鉴权。成功时状态码为 200，响应体是该 id 对应的一条完整图书记录 JSON；若不存在该 id 则为 404。

POST /api/v1/books/  
需 X-API-Key（除非 DISABLE_AUTH=true）。请求体为 BookCreate。创建成功时状态码为 201，响应体是一条完整图书记录的 JSON，其中 id 由服务器分配。

PATCH /api/v1/books/{book_id}  
需 X-API-Key（除非 DISABLE_AUTH=true）。请求体为 BookUpdate。更新成功时状态码为 200，响应体是该书在修改后的完整图书记录 JSON；若 id 不存在则为 404。

DELETE /api/v1/books/{book_id}  
需 X-API-Key（除非 DISABLE_AUTH=true）。204 表示删除成功且无响应体；404 表示不存在。

GET /api/v1/analytics/summary  
无鉴权。200 返回第 5 节所述汇总结构。


7. CSV 批量导入（非 HTTP）

与接口建书使用同一套字段校验。在项目根目录执行：

python scripts/import_csv.py --replace

默认读取 data/books_gutenberg_catalog_sample.csv。使用 --replace 会先清空 books 表再导入。


服务启动后还可通过 GET /docs（Swagger）、GET /redoc、GET /openapi.json 查看机器可读契约并在浏览器中试调。
