"""Generate docs from the FastAPI OpenAPI schema (Swagger UI /openapi.json) into PDF."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
DOCS.mkdir(exist_ok=True)

# fpdf multi_cell can clip the last few millimetres in some PDF viewers; widen right margin for API PDF only.
API_PDF_RIGHT_MARGIN_MM = 22.0

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _clean_pdf_text(s: str) -> str:
    return (
        s.replace("\u2014", "-")
        .replace("\u2013", "-")
        .replace("\u201c", '"')
        .replace("\u201d", '"')
        .replace("\u2019", "'")
    )


def _fpdf_safe(s: str) -> str:
    """fpdf2 core fonts only support latin-1; drop/replace anything else."""
    return _clean_pdf_text(s).encode("latin-1", "replace").decode("latin-1")


def _mc(pdf: Any, w: float, h: float, txt: str) -> None:
    """multi_cell from left margin. FPDF leaves x at end of last line after wrap; next multi_cell would start off-page."""
    pdf.set_x(pdf.l_margin)
    pdf.multi_cell(w, h, txt)


def _write_text_no_trunc(pdf: Any, col_w: float, line_h: float, text: str, *, safe: bool = True) -> None:
    """
    Write full text without truncating characters. Long lines are split using get_string_width,
    then each segment is emitted with multi_cell (same approach as before the cell() experiment).
    """
    body = _fpdf_safe(text) if safe else text
    left = pdf.l_margin
    # Slightly narrower than cell width so glyphs stay inside the drawable area.
    max_w = col_w - 3
    for raw in body.split("\n"):
        if raw == "":
            pdf.set_x(left)
            pdf.ln(line_h * 0.35)
            continue
        start = 0
        n = len(raw)
        while start < n:
            lo, hi = start + 1, n + 1
            best = start + 1
            while lo < hi:
                mid = (lo + hi) // 2
                chunk = raw[start:mid]
                tw = pdf.get_string_width(chunk)
                if tw <= max_w:
                    best = mid
                    lo = mid + 1
                else:
                    hi = mid
            if best <= start:
                best = start + 1
            piece = raw[start:best]
            pdf.set_x(left)
            _mc(pdf, col_w, line_h, piece)
            start = best
    pdf.set_x(pdf.l_margin)


def _deref(root: Dict[str, Any], node: Any) -> Any:
    if not isinstance(node, dict):
        return node
    ref = node.get("$ref")
    if isinstance(ref, str) and ref.startswith("#/"):
        cur: Any = root
        for part in ref[2:].split("/"):
            cur = cur[part]
        return cur
    return node


def _schema_properties_lines(root: Dict[str, Any], schema: Dict[str, Any], indent: str = "") -> List[str]:
    schema = _deref(root, schema)
    if not isinstance(schema, dict):
        return [indent + "(see OpenAPI ref)"]
    lines: List[str] = []
    if "properties" in schema:
        req = set(schema.get("required") or [])
        for pname, pdef in schema["properties"].items():
            pdef = _deref(root, pdef)
            r = "required" if pname in req else "optional"
            if not isinstance(pdef, dict):
                lines.append(f"{indent}- {pname} ({r})")
                continue
            typ = pdef.get("type", "any")
            if pdef.get("anyOf"):
                typ = " | ".join(
                    str(x.get("type", x.get("$ref", "?"))) for x in pdef["anyOf"] if isinstance(x, dict)
                )
            extra = []
            if "minimum" in pdef or "maximum" in pdef:
                extra.append(f"min={pdef.get('minimum', '?')}, max={pdef.get('maximum', '?')}")
            if "minLength" in pdef or "maxLength" in pdef:
                extra.append(f"len {pdef.get('minLength', '')}-{pdef.get('maxLength', '')}")
            suf = f" ({', '.join(extra)})" if extra else ""
            lines.append(f"{indent}- {pname}: {typ} ({r}){suf}")
    elif schema.get("type") == "array" and "items" in schema:
        it = _deref(root, schema["items"])
        lines.append(indent + "- array items:")
        lines.extend(_schema_properties_lines(root, it if isinstance(it, dict) else {}, indent + "  "))
    else:
        lines.append(indent + f"- type: {schema.get('type', 'object')}")
    return lines


def _merge_parameters(path_item: Dict[str, Any], op: Dict[str, Any]) -> List[Dict[str, Any]]:
    seen: Set[Tuple[str, str]] = set()
    out: List[Dict[str, Any]] = []
    for p in (path_item.get("parameters") or []) + (op.get("parameters") or []):
        if not isinstance(p, dict):
            continue
        key = (str(p.get("name", "")), str(p.get("in", "")))
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def _param_detail(root: Dict[str, Any], p: Dict[str, Any]) -> str:
    loc = p.get("in", "?")
    name = p.get("name", "?")
    req = "required" if p.get("required") else "optional"
    sch = _deref(root, p.get("schema", {}))
    if not isinstance(sch, dict):
        return f"    - {name} ({loc}, {req}): ?"
    typ = sch.get("type", "any")
    bits: List[str] = [str(typ)]
    if "default" in sch:
        bits.append(f"default={sch['default']}")
    if "minimum" in sch:
        bits.append(f"minimum={sch['minimum']}")
    if "maximum" in sch:
        bits.append(f"maximum={sch['maximum']}")
    if "minLength" in sch:
        bits.append(f"minLength={sch['minLength']}")
    if "maxLength" in sch:
        bits.append(f"maxLength={sch['maxLength']}")
    extra = p.get("description")
    tail = f" ({_fpdf_safe(str(extra))})" if extra else ""
    return f"    - {name} ({loc}, {req}): " + ", ".join(bits) + tail


def _operation_block(
    root: Dict[str, Any], method: str, path: str, op: Dict[str, Any], path_item: Dict[str, Any]
) -> List[str]:
    lines: List[str] = []
    m = method.upper()
    summary = op.get("summary") or op.get("operationId") or ""
    lines.append(f"{m} {path}")
    tags = op.get("tags")
    if tags:
        lines.append(f"  Tags: {', '.join(str(t) for t in tags)}")
    if summary:
        lines.append(f"  Summary: {_fpdf_safe(str(summary))}")
    desc = op.get("description")
    if desc and desc != summary:
        lines.append(f"  Description: {_fpdf_safe(str(desc))}")
    params = _merge_parameters(path_item, op)
    if params:
        lines.append("  Parameters:")
        for p in params:
            lines.append(_param_detail(root, p))
    rb = op.get("requestBody")
    if isinstance(rb, dict):
        req_rb = rb.get("required", False)
        lines.append(f"  Request body: application/json (required={req_rb})")
        content = rb.get("content", {}).get("application/json", {})
        raw_sch = content.get("schema", {})
        sch = _deref(root, raw_sch)
        if isinstance(sch, dict) and "properties" in sch:
            lines.extend("    " + x for x in _schema_properties_lines(root, sch, "  "))
        elif isinstance(raw_sch, dict) and "$ref" in raw_sch:
            lines.append(f"    Schema ref: {raw_sch['$ref']}")
            if isinstance(sch, dict):
                lines.extend("    " + x for x in _schema_properties_lines(root, sch, "  "))
    sec = op.get("security")
    if sec is not None:
        lines.append(f"  Security (OpenAPI): {json.dumps(sec, ensure_ascii=True)}")
    lines.append("  Responses:")
    for code, resp in sorted((op.get("responses") or {}).items(), key=lambda x: x[0]):
        if not isinstance(resp, dict):
            continue
        desc = resp.get("description", "")
        detail = f" - {desc}" if desc else ""
        lines.append(f"    - {code}{detail}")
        for ct, cobj in (resp.get("content") or {}).items():
            if ct != "application/json":
                continue
            sch_node = cobj.get("schema")
            if isinstance(sch_node, dict) and "$ref" in sch_node:
                lines.append(f"      body ({ct}): {sch_node['$ref']}")
                expanded = _deref(root, sch_node)
                if isinstance(expanded, dict):
                    elines = _schema_properties_lines(root, expanded, "        ")
                    for el in elines:
                        lines.append(el)
            elif isinstance(sch_node, dict):
                lines.append(f"      body ({ct}):")
                for el in _schema_properties_lines(root, sch_node, "        "):
                    lines.append(el)
    lines.append("")
    return lines


def build_api_pdf() -> None:
    from fpdf import FPDF

    from app.main import app

    app.openapi_schema = None
    schema = app.openapi()

    openapi_path = DOCS / "openapi.json"
    openapi_path.write_text(json.dumps(schema, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    print(f"Wrote {openapi_path}")

    pdf = FPDF()
    pdf.set_margins(14, 14, API_PDF_RIGHT_MARGIN_MM)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    col_w = pdf.w - pdf.l_margin - pdf.r_margin

    info = schema.get("info", {})
    title = info.get("title", "API")
    version = info.get("version", "")
    pdf.set_font("Helvetica", "B", 16)
    _mc(pdf, col_w, 9, _fpdf_safe(str(title)))
    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, _fpdf_safe(f"API documentation (PDF) - OpenAPI / Swagger UI export - v{version}"))
    pdf.ln(2)
    pdf.set_font("Helvetica", "", 9)
    intro = (
        "This PDF is generated from the same OpenAPI 3 schema used by Swagger UI at GET /docs and "
        "the raw spec at GET /openapi.json (also saved as docs/openapi.json in this repository). "
        "Regenerate with: python scripts/generate_docs.py"
    )
    _mc(pdf, col_w, 4, _fpdf_safe(intro))
    pdf.ln(2)
    desc = info.get("description")
    if desc:
        _mc(pdf, col_w, 4, _fpdf_safe(str(desc)))
        pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Servers (Try it out base URL)")
    pdf.set_font("Helvetica", "", 9)
    for s in schema.get("servers") or [{"url": "(not set)"}]:
        _mc(pdf, col_w, 4, f"  - {s.get('url', '')} {s.get('description', '')}".strip())
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Authentication")
    pdf.set_font("Helvetica", "", 9)
    _mc(
        pdf,
        col_w,
        4,
        "Book mutations (POST/PATCH/DELETE under /api/v1/books) require header X-API-Key matching "
        "environment API_KEY. When DISABLE_AUTH=true, the server skips this check (local/testing). "
        "401 response: detail explains invalid or missing key; WWW-Authenticate: ApiKey. "
        "OpenAPI security scheme name: ApiKeyAuth (see components in openapi.json).",
    )
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Common error responses")
    pdf.set_font("Helvetica", "", 9)
    _mc(
        pdf,
        col_w,
        4,
        "422 Unprocessable Entity: {\"detail\": [<Pydantic errors>], \"code\": \"validation_error\"} "
        "(request or query validation). 404 Not Found: {\"detail\": \"Book not found\"} for unknown book id.",
    )
    pdf.ln(2)

    paths: Dict[str, Any] = schema.get("paths") or {}

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Security schemes (OpenAPI components.securitySchemes)")
    pdf.set_font("Courier", "", 6)
    sec_comps = (schema.get("components") or {}).get("securitySchemes") or {}
    sec_json = json.dumps(sec_comps, indent=2, ensure_ascii=True)
    _write_text_no_trunc(pdf, col_w, 3, sec_json, safe=True)
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "HTTP status reference")
    pdf.set_font("Helvetica", "", 9)
    status_lines = [
        "200 OK - Successful GET (list, one book, analytics), PATCH (updated book); JSON body unless noted.",
        "201 Created - POST /api/v1/books/; response body is the new book including id.",
        "204 No Content - DELETE /api/v1/books/{book_id} success; empty body.",
        "401 Unauthorized - Mutating book route without valid X-API-Key (when auth enabled).",
        "404 Not Found - Unknown book_id for GET/PATCH/DELETE single book.",
        "422 Unprocessable Entity - Invalid JSON body or query params; see validation_error above.",
    ]
    for sl in status_lines:
        _mc(pdf, col_w, 4, _fpdf_safe(sl))
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Endpoint index (all operations)")
    pdf.set_font("Courier", "", 7)
    for path_key in sorted(paths.keys()):
        path_item = paths[path_key]
        if not isinstance(path_item, dict):
            continue
        for method in ("get", "post", "put", "patch", "delete"):
            if method not in path_item:
                continue
            _write_text_no_trunc(pdf, col_w, 3.5, f"{method.upper()} {path_key}", safe=True)
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Endpoints (OpenAPI detail: parameters, bodies, responses)")
    pdf.ln(1)
    pdf.set_font("Courier", "", 7)
    path_lines: List[str] = []
    for path_key in sorted(paths.keys()):
        path_item = paths[path_key]
        if not isinstance(path_item, dict):
            continue
        for method in ("get", "post", "put", "patch", "delete"):
            if method not in path_item:
                continue
            op = path_item[method]
            if not isinstance(op, dict):
                continue
            path_lines.extend(_operation_block(schema, method, path_key, op, path_item))
    body_text = "\n".join(path_lines) or "(no paths)"
    _write_text_no_trunc(pdf, col_w, 3.5, body_text, safe=True)
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 11)
    _mc(pdf, col_w, 7, "Component schemas (full field list per model)")
    pdf.set_font("Helvetica", "", 8)
    comps = (schema.get("components") or {}).get("schemas") or {}
    for name in sorted(comps.keys()):
        pdf.set_font("Helvetica", "B", 9)
        _mc(pdf, col_w, 4, name)
        pdf.set_font("Helvetica", "", 8)
        slines = _schema_properties_lines(schema, comps[name])
        _write_text_no_trunc(pdf, col_w, 3.5, "\n".join(slines), safe=True)
        pdf.ln(1)

    pdf.add_page()
    pdf.set_font("Helvetica", "B", 12)
    _mc(pdf, col_w, 8, "Implementation notes (runtime behaviour)")
    pdf.ln(2)
    pdf.set_font("Helvetica", "", 9)
    impl_notes = [
        "Startup: lifespan hook calls init_db() so SQLite tables exist before serving.",
        "Database: default DATABASE_URL=sqlite:///./books.db; override in .env for PostgreSQL etc.",
        "List books: ordered by id ascending; query genre uses exact equality match (case-sensitive).",
        "Analytics: aggregates over all rows in books - total count, per-genre count and avg(rating), overall avg(rating); null averages when no ratings.",
        "GET / returns HTML (landing page), not JSON - use /health or /openapi.json from scripts.",
        "Data load (not REST): python scripts/import_csv.py --replace imports CSV into the database.",
    ]
    for note in impl_notes:
        _mc(pdf, col_w, 4, _fpdf_safe(note))
        pdf.ln(1)
    pdf.ln(2)

    pdf.set_font("Helvetica", "B", 12)
    _mc(pdf, col_w, 8, "Example requests and expected JSON")
    pdf.ln(2)
    pdf.set_font("Helvetica", "", 9)
    examples_intro = (
        "Examples match app/schemas.py and typical responses. Base URL example: http://127.0.0.1:8000. "
        "Use the same value as API_KEY in .env for header X-API-Key on POST/PATCH/DELETE."
    )
    _mc(pdf, col_w, 4, examples_intro)
    pdf.ln(2)

    examples: List[tuple[str, str]] = [
        (
            "GET / (browser or curl) - response is HTML, not JSON",
            "Content-Type: text/html; charset=utf-8\n(landing page with links to /docs, /openapi.json, /health)",
        ),
        (
            "GET /health",
            json.dumps({"status": "ok"}, indent=2, ensure_ascii=True),
        ),
        (
            "GET /api/v1/books/1 - 200 one book (no API key)",
            json.dumps(
                {
                    "title": "Example",
                    "author": "Jane Doe",
                    "genre": "Fiction",
                    "publication_year": 2020,
                    "rating": 3.5,
                    "notes": None,
                    "id": 1,
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "GET /api/v1/books/99999 - 404 unknown id",
            json.dumps({"detail": "Book not found"}, indent=2, ensure_ascii=True),
        ),
        (
            "POST /api/v1/books/ (header X-API-Key: <API_KEY>)",
            json.dumps(
                {
                    "title": "Example",
                    "author": "Jane Doe",
                    "genre": "Fiction",
                    "publication_year": 2020,
                    "rating": 4.2,
                    "notes": None,
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "Expected 201 response body (POST /api/v1/books/)",
            json.dumps(
                {
                    "title": "Example",
                    "author": "Jane Doe",
                    "genre": "Fiction",
                    "publication_year": 2020,
                    "rating": 4.2,
                    "notes": None,
                    "id": 1,
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "PATCH /api/v1/books/1 (header X-API-Key; partial body)",
            json.dumps({"rating": 3.5}, indent=2, ensure_ascii=True),
        ),
        (
            "Expected 200 response body (PATCH /api/v1/books/1)",
            json.dumps(
                {
                    "title": "Example",
                    "author": "Jane Doe",
                    "genre": "Fiction",
                    "publication_year": 2020,
                    "rating": 3.5,
                    "notes": None,
                    "id": 1,
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "DELETE /api/v1/books/1 (header X-API-Key) on success",
            "HTTP 204 No Content\n(empty body - no JSON)",
        ),
        (
            "GET /api/v1/books/?skip=0&limit=10&genre=Fiction",
            json.dumps(
                [
                    {
                        "id": 1,
                        "title": "Example",
                        "author": "Jane Doe",
                        "genre": "Fiction",
                        "publication_year": 2020,
                        "rating": 3.5,
                        "notes": None,
                    }
                ],
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "GET /api/v1/analytics/summary",
            json.dumps(
                {
                    "total_books": 2,
                    "genres": [
                        {"genre": "Fiction", "count": 1, "average_rating": 4.0},
                        {"genre": "Science", "count": 1, "average_rating": None},
                    ],
                    "average_rating_overall": 4.0,
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
        (
            "401 Unauthorized (missing/invalid API key on mutation)",
            json.dumps({"detail": "Invalid or missing API key. Send header X-API-Key."}, indent=2, ensure_ascii=True),
        ),
        (
            "422 validation (shape example)",
            json.dumps(
                {
                    "detail": [{"type": "string_too_long", "loc": ["body", "title"], "msg": "..."}],
                    "code": "validation_error",
                },
                indent=2,
                ensure_ascii=True,
            ),
        ),
    ]

    for heading, payload in examples:
        pdf.set_font("Helvetica", "B", 9)
        _mc(pdf, col_w, 5, _fpdf_safe(heading))
        pdf.set_font("Courier", "", 7)
        _write_text_no_trunc(pdf, col_w, 3.5, payload, safe=True)
        pdf.ln(2)

    out = DOCS / "API_DOCUMENTATION.pdf"
    pdf.output(out.as_posix())
    print(f"Wrote {out}")


def _clean_md_line(line: str) -> str:
    line = line.strip()
    line = re.sub(r"\*\*(.+?)\*\*", r"\1", line)
    line = re.sub(r"`([^`]+)`", r"\1", line)
    line = line.replace("\u2014", "-").replace("\u2013", "-")
    line = line.replace("\u201c", '"').replace("\u201d", '"')
    line = line.replace("\u2019", "'")
    line = line.replace("\u2192", "->")
    return line


def build_report_pdf() -> None:
    from fpdf import FPDF

    report_md = DOCS / "TECHNICAL_REPORT.md"
    if not report_md.is_file():
        print(f"Missing {report_md}; skipping TECHNICAL_REPORT.pdf", file=sys.stderr)
        return

    raw = report_md.read_text(encoding="utf-8")
    pdf = FPDF()
    pdf.set_margins(14, 14, 14)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    col_w = pdf.w - pdf.l_margin - pdf.r_margin

    for line in raw.splitlines():
        s = line.strip()
        if not s or s == "---":
            pdf.ln(2)
            continue
        if s.startswith("|") and "|" in s[1:]:
            pdf.set_font("Helvetica", "", 8)
            _mc(pdf, col_w, 3, _clean_md_line(s))
            continue
        if s.startswith("### "):
            pdf.set_font("Helvetica", "B", 10)
            _mc(pdf, col_w, 5, _clean_md_line(s[4:]))
            pdf.ln(1)
            continue
        if s.startswith("## "):
            pdf.set_font("Helvetica", "B", 12)
            _mc(pdf, col_w, 6, _clean_md_line(s[3:]))
            pdf.ln(1)
            continue
        if s.startswith("# "):
            pdf.set_font("Helvetica", "B", 14)
            _mc(pdf, col_w, 7, _clean_md_line(s[2:]))
            pdf.ln(2)
            continue
        if s.startswith("- "):
            pdf.set_font("Helvetica", "", 9)
            _mc(pdf, col_w, 4, "  - " + _clean_md_line(s[2:]))
            continue
        pdf.set_font("Helvetica", "", 9)
        _mc(pdf, col_w, 4, _clean_md_line(s))

    out = DOCS / "TECHNICAL_REPORT.pdf"
    pdf.output(out.as_posix())
    print(f"Wrote {out}")


def main() -> None:
    try:
        build_api_pdf()
        build_report_pdf()
    except ImportError:
        print("Install fpdf2: pip install fpdf2", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
