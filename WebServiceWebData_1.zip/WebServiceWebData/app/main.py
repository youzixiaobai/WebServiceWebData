from contextlib import asynccontextmanager
from typing import Dict

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.openapi.utils import get_openapi
from fastapi.responses import HTMLResponse, JSONResponse

from app.database import init_db
from app.routers import analytics, books


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="Book Library & Analytics API",
    description=(
        "REST API for managing books (CRUD) with SQL persistence and aggregate analytics. "
        "Mutating requests require `X-API-Key` unless `DISABLE_AUTH=true`."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(books.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")


@app.exception_handler(RequestValidationError)
async def validation_handler(_request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={"detail": exc.errors(), "code": "validation_error"},
    )


@app.get("/health", tags=["health"])
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.get("/", tags=["health"], response_class=HTMLResponse)
def root() -> str:
    """Browser-friendly landing page; JSON clients can use /openapi.json or /health."""
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Book Library API</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 36rem; margin: 3rem auto; padding: 0 1rem; line-height: 1.5; }
    h1 { font-size: 1.35rem; }
    a { color: #0b57d0; }
    ul { padding-left: 1.2rem; }
    .muted { color: #444; font-size: 0.9rem; }
  </style>
</head>
<body>
  <h1>Book Library &amp; Analytics API</h1>
  <p class="muted">This is a backend API (not a traditional website). Use the links below to explore and test endpoints.</p>
  <ul>
    <li><a href="/docs"><strong>Swagger UI</strong></a> — try requests in the browser</li>
    <li><a href="/redoc">ReDoc</a> — alternative API reference</li>
    <li><a href="/openapi.json">OpenAPI JSON</a> — machine-readable spec</li>
    <li><a href="/health">Health check</a> — <code>{"status":"ok"}</code></li>
  </ul>
</body>
</html>"""


def custom_openapi():
    """Same schema as GET /openapi.json and Swagger UI (/docs); adds ApiKey security for book mutations."""
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    openapi_schema.setdefault("servers", [{"url": "http://127.0.0.1:8000", "description": "Local uvicorn (default)"}])
    schemes = openapi_schema.setdefault("components", {}).setdefault("securitySchemes", {})
    schemes["ApiKeyAuth"] = {
        "type": "apiKey",
        "in": "header",
        "name": "X-API-Key",
        "description": "Value must match environment variable API_KEY (see .env.example). Omit when DISABLE_AUTH=true.",
    }
    for path_key, path_item in openapi_schema.get("paths", {}).items():
        if not path_key.startswith("/api/v1/books"):
            continue
        for method, operation in path_item.items():
            if method.lower() not in ("post", "patch", "delete"):
                continue
            if not isinstance(operation, dict):
                continue
            operation["security"] = [{"ApiKeyAuth": []}]
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi
