from typing import Optional

from typing_extensions import Annotated

from fastapi import Depends, Header, HTTPException, status
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db


def verify_api_key(x_api_key: Annotated[Optional[str], Header()] = None) -> None:
    settings = get_settings()
    if settings.disable_auth:
        return
    if not x_api_key or x_api_key != settings.api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key. Send header X-API-Key.",
            headers={"WWW-Authenticate": "ApiKey"},
        )


DbSession = Annotated[Session, Depends(get_db)]
RequireAuth = Annotated[None, Depends(verify_api_key)]
