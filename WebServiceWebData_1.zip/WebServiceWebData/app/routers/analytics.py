from fastapi import APIRouter

from app import crud, schemas
from app.deps import DbSession

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/summary", response_model=schemas.AnalyticsSummary)
def genre_summary(db: DbSession) -> schemas.AnalyticsSummary:
    return crud.analytics_summary(db)
