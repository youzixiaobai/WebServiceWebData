from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query, status

from app import crud, schemas
from app.deps import DbSession, RequireAuth

router = APIRouter(prefix="/books", tags=["books"])


@router.post("/", response_model=schemas.BookRead, status_code=status.HTTP_201_CREATED)
def create_book(_: RequireAuth, db: DbSession, payload: schemas.BookCreate) -> schemas.BookRead:
    book = crud.create_book(db, payload)
    return schemas.BookRead.model_validate(book)


@router.get("/", response_model=List[schemas.BookRead])
def list_books(
    db: DbSession,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    genre: Optional[str] = None,
) -> List[schemas.BookRead]:
    books = crud.list_books(db, skip=skip, limit=limit, genre=genre)
    return [schemas.BookRead.model_validate(b) for b in books]


@router.get("/{book_id}", response_model=schemas.BookRead)
def get_book(db: DbSession, book_id: int) -> schemas.BookRead:
    book = crud.get_book(db, book_id)
    if not book:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
    return schemas.BookRead.model_validate(book)


@router.patch("/{book_id}", response_model=schemas.BookRead)
def update_book(_: RequireAuth, db: DbSession, book_id: int, payload: schemas.BookUpdate) -> schemas.BookRead:
    book = crud.get_book(db, book_id)
    if not book:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
    updated = crud.update_book(db, book, payload)
    return schemas.BookRead.model_validate(updated)


@router.delete("/{book_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_book(_: RequireAuth, db: DbSession, book_id: int) -> None:
    book = crud.get_book(db, book_id)
    if not book:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Book not found")
    crud.delete_book(db, book)
