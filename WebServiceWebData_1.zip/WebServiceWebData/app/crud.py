from typing import List, Optional

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app import models, schemas


def create_book(db: Session, data: schemas.BookCreate) -> models.Book:
    book = models.Book(**data.model_dump())
    db.add(book)
    db.commit()
    db.refresh(book)
    return book


def get_book(db: Session, book_id: int) -> Optional[models.Book]:
    return db.get(models.Book, book_id)


def list_books(
    db: Session, skip: int = 0, limit: int = 50, genre: Optional[str] = None
) -> List[models.Book]:
    q = select(models.Book).order_by(models.Book.id)
    if genre:
        q = q.where(models.Book.genre == genre)
    q = q.offset(skip).limit(min(limit, 100))
    return list(db.scalars(q).all())


def update_book(db: Session, book: models.Book, data: schemas.BookUpdate) -> models.Book:
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(book, field, value)
    db.add(book)
    db.commit()
    db.refresh(book)
    return book


def delete_book(db: Session, book: models.Book) -> None:
    db.delete(book)
    db.commit()


def analytics_summary(db: Session) -> schemas.AnalyticsSummary:
    total = db.scalar(select(func.count()).select_from(models.Book)) or 0
    avg_all = db.scalar(select(func.avg(models.Book.rating)).where(models.Book.rating.isnot(None)))

    rows = db.execute(
        select(
            models.Book.genre,
            func.count(models.Book.id),
            func.avg(models.Book.rating),
        ).group_by(models.Book.genre)
    ).all()

    genres = [
        schemas.GenreStat(genre=r[0], count=int(r[1]), average_rating=float(r[2]) if r[2] is not None else None)
        for r in rows
    ]
    return schemas.AnalyticsSummary(
        total_books=int(total),
        genres=genres,
        average_rating_overall=float(avg_all) if avg_all is not None else None,
    )
