from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field


class BookBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    author: str = Field(..., min_length=1, max_length=300)
    genre: str = Field(..., min_length=1, max_length=120)
    publication_year: Optional[int] = Field(None, ge=1000, le=2100)
    rating: Optional[float] = Field(None, ge=0, le=5)
    notes: Optional[str] = None


class BookCreate(BookBase):
    pass


class BookUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=500)
    author: Optional[str] = Field(None, min_length=1, max_length=300)
    genre: Optional[str] = Field(None, min_length=1, max_length=120)
    publication_year: Optional[int] = Field(None, ge=1000, le=2100)
    rating: Optional[float] = Field(None, ge=0, le=5)
    notes: Optional[str] = None


class BookRead(BookBase):
    model_config = ConfigDict(from_attributes=True)

    id: int


class GenreStat(BaseModel):
    genre: str
    count: int
    average_rating: Optional[float]


class AnalyticsSummary(BaseModel):
    total_books: int
    genres: List[GenreStat]
    average_rating_overall: Optional[float]


class ErrorResponse(BaseModel):
    detail: str
    code: Optional[str] = None
