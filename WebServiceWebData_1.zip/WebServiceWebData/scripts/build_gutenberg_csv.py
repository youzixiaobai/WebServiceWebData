"""
Rebuild data/books_gutenberg_catalog_sample.csv from the official Project Gutenberg
bibliographic catalog feed (same field semantics as import_csv.py).

Catalog URL: https://www.gutenberg.org/cache/epub/feeds/pg_catalog.csv
Run from repo root: python scripts/build_gutenberg_csv.py
"""

from __future__ import annotations

import csv
import sys
from io import TextIOWrapper
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "books_gutenberg_catalog_sample.csv"
CATALOG = "https://www.gutenberg.org/cache/epub/feeds/pg_catalog.csv"


def genre_from_subjects(s: str) -> str:
    if not s:
        return "Literature"
    sl = s.lower()
    if "fiction" in sl:
        return "Fiction"
    if "science" in sl:
        return "Science"
    if "history" in sl:
        return "History"
    if "poetry" in sl:
        return "Poetry"
    if "biography" in sl:
        return "Biography"
    part = s.split(";")[0].strip()
    return part if len(part) <= 120 else part[:117] + "..."


def main() -> None:
    targets = {"Fiction": 8, "History": 5, "Science": 4, "Poetry": 3, "Other": 6}
    buckets: Dict[str, List[Tuple[str, str, str, str]]] = {k: [] for k in targets}
    scanned = 0
    max_scan = 12000

    with urlopen(CATALOG, timeout=120) as resp:
        reader = csv.DictReader(TextIOWrapper(resp, encoding="utf-8"))
        for row in reader:
            scanned += 1
            if scanned > max_scan:
                break
            if row.get("Type") != "Text":
                continue
            if row.get("Language", "").split(",")[0].strip() != "en":
                continue
            tid = (row.get("Text#") or "").strip()
            title = (row.get("Title") or "").strip()
            authors = (row.get("Authors") or "").strip()
            subj = row.get("Subjects") or ""
            if not tid or not title or not authors or authors == "Anonymous":
                continue
            if len(title) > 500 or len(authors) > 300:
                continue
            g = genre_from_subjects(subj)
            if g not in buckets:
                g = "Other"
            issued = (row.get("Issued") or "").strip()
            notes = (
                f"Project Gutenberg Text#{tid}; catalog issued {issued}; "
                f"https://www.gutenberg.org/ebooks/{tid}"
            )
            item = (title, authors, g, notes)
            if len(buckets[g]) < targets[g]:
                buckets[g].append(item)
            if all(len(buckets[k]) >= targets[k] for k in targets):
                break

    order = ["Fiction", "History", "Science", "Poetry", "Other"]
    rows: List[Tuple[str, str, str, str, str, str]] = []
    for k in order:
        for title, authors, g, notes in buckets[k]:
            rows.append((title, authors, g, "", "", notes))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["title", "author", "genre", "publication_year", "rating", "notes"])
        for title, authors, genre, year, rating, notes in rows:
            w.writerow([title, authors, genre, year, rating, notes])

    print(f"Wrote {len(rows)} rows to {OUT} (scanned {scanned} catalog lines)")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
