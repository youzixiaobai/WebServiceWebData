"""Load sample rows into the books table (run after starting app once or call init_db)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sqlalchemy import func, select

from app.config import get_settings  # noqa: E402
from app.crud import create_book  # noqa: E402
from app.database import SessionLocal, init_db  # noqa: E402
from app.models import Book  # noqa: E402
from app.schemas import BookCreate  # noqa: E402

SAMPLES = [
    {
        "title": "The Pragmatic Programmer",
        "author": "David Thomas",
        "genre": "Software",
        "publication_year": 2019,
        "rating": 4.8,
        "notes": "Classic software craftsmanship.",
    },
    {
        "title": "Designing Data-Intensive Applications",
        "author": "Martin Kleppmann",
        "genre": "Software",
        "publication_year": 2017,
        "rating": 4.9,
        "notes": None,
    },
    {
        "title": "Clean Architecture",
        "author": "Robert C. Martin",
        "genre": "Software",
        "publication_year": 2017,
        "rating": 4.5,
        "notes": None,
    },
    {
        "title": "Sapiens",
        "author": "Yuval Noah Harari",
        "genre": "History",
        "publication_year": 2011,
        "rating": 4.6,
        "notes": None,
    },
    {
        "title": "1984",
        "author": "George Orwell",
        "genre": "Fiction",
        "publication_year": 1949,
        "rating": 4.7,
        "notes": None,
    },
]


def main() -> None:
    get_settings()
    init_db()
    db = SessionLocal()
    try:
        n = db.scalar(select(func.count()).select_from(Book)) or 0
        if n > 0:
            print(f"Database already has {n} books; skipping seed.")
            return
        for row in SAMPLES:
            create_book(db, BookCreate(**row))
        print(f"Inserted {len(SAMPLES)} books.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
