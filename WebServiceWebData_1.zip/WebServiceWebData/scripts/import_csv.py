"""
Import book rows from a CSV file into the SQLite (or configured) database.

Default file: data/books_gutenberg_catalog_sample.csv

Usage:
  python scripts/import_csv.py
  python scripts/import_csv.py --file data/books_gutenberg_catalog_sample.csv --replace
"""

import argparse
import csv
import sys
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sqlalchemy import delete  # noqa: E402

from app import models  # noqa: E402
from app.config import get_settings  # noqa: E402
from app.crud import create_book  # noqa: E402
from app.database import SessionLocal, init_db  # noqa: E402
from app.schemas import BookCreate  # noqa: E402


def _parse_int(raw: str) -> Optional[int]:
    raw = (raw or "").strip()
    if not raw:
        return None
    return int(raw)


def _parse_float(raw: str) -> Optional[float]:
    raw = (raw or "").strip()
    if not raw:
        return None
    return float(raw)


def import_csv(path: Path, replace: bool) -> int:
    get_settings()
    init_db()
    db = SessionLocal()
    try:
        if replace:
            db.execute(delete(models.Book))
            db.commit()

        count = 0
        with path.open(encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            required = {"title", "author", "genre"}
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                raise SystemExit(
                    f"CSV must have columns: {sorted(required)}. Found: {reader.fieldnames}"
                )
            for row in reader:
                title = (row.get("title") or "").strip()
                author = (row.get("author") or "").strip()
                genre = (row.get("genre") or "").strip()
                if not title or not author or not genre:
                    continue
                payload = BookCreate(
                    title=title,
                    author=author,
                    genre=genre,
                    publication_year=_parse_int(row.get("publication_year") or ""),
                    rating=_parse_float(row.get("rating") or ""),
                    notes=(row.get("notes") or "").strip() or None,
                )
                create_book(db, payload)
                count += 1
        return count
    finally:
        db.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Import books from CSV into the database.")
    parser.add_argument(
        "--file",
        type=Path,
        default=ROOT / "data" / "books_gutenberg_catalog_sample.csv",
        help="Path to CSV file",
    )
    parser.add_argument(
        "--replace",
        action="store_true",
        help="Delete all existing books before import",
    )
    args = parser.parse_args()
    if not args.file.is_file():
        raise SystemExit(f"File not found: {args.file}")

    n = import_csv(args.file, replace=args.replace)
    print(f"Imported {n} rows from {args.file}")


if __name__ == "__main__":
    main()
