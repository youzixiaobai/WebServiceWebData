import pytest
from fastapi.testclient import TestClient


def test_health(client: TestClient) -> None:
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_crud_flow(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={
            "title": "Test Book",
            "author": "A. Tester",
            "genre": "Fiction",
            "publication_year": 2020,
            "rating": 4.0,
            "notes": "unit test",
        },
    )
    assert r.status_code == 201
    bid = r.json()["id"]

    r = client.get(f"/api/v1/books/{bid}")
    assert r.status_code == 200
    assert r.json()["title"] == "Test Book"

    r = client.patch(
        "/api/v1/books/" + str(bid),
        json={"rating": 3.5},
    )
    assert r.status_code == 200
    assert r.json()["rating"] == 3.5

    r = client.get("/api/v1/books/")
    assert r.status_code == 200
    assert len(r.json()) >= 1

    r = client.delete("/api/v1/books/" + str(bid))
    assert r.status_code == 204

    r = client.get(f"/api/v1/books/{bid}")
    assert r.status_code == 404


def test_analytics(client: TestClient) -> None:
    client.post(
        "/api/v1/books/",
        json={
            "title": "Analytics Book",
            "author": "B. Data",
            "genre": "Science",
            "publication_year": 2021,
            "rating": 5.0,
            "notes": None,
        },
    )
    r = client.get("/api/v1/analytics/summary")
    assert r.status_code == 200
    body = r.json()
    assert "total_books" in body
    assert "genres" in body
    assert body["total_books"] >= 1


def test_validation_error(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={"title": "", "author": "X", "genre": "Y"},
    )
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"


def test_title_max_length_enforced(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={
            "title": "x" * 501,
            "author": "Author",
            "genre": "Fiction",
        },
    )
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"


def test_author_max_length_enforced(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={
            "title": "T",
            "author": "y" * 301,
            "genre": "Fiction",
        },
    )
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"


def test_rating_range_enforced(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={
            "title": "R",
            "author": "A",
            "genre": "G",
            "rating": 5.01,
        },
    )
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"


def test_publication_year_range_enforced(client: TestClient) -> None:
    r = client.post(
        "/api/v1/books/",
        json={
            "title": "Y",
            "author": "A",
            "genre": "G",
            "publication_year": 999,
        },
    )
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"


def test_list_books_genre_filter(client: TestClient) -> None:
    client.post(
        "/api/v1/books/",
        json={"title": "G1", "author": "A", "genre": "Alpha", "rating": 3.0},
    )
    client.post(
        "/api/v1/books/",
        json={"title": "G2", "author": "B", "genre": "Beta", "rating": 4.0},
    )
    r = client.get("/api/v1/books/", params={"genre": "Alpha"})
    assert r.status_code == 200
    titles = {b["title"] for b in r.json()}
    assert "G1" in titles
    assert "G2" not in titles


def test_list_books_limit_query_upper_bound(client: TestClient) -> None:
    r = client.get("/api/v1/books/", params={"limit": 101})
    assert r.status_code == 422
    assert r.json().get("code") == "validation_error"
