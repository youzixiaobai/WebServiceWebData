import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app import models  # noqa: F401
from app.config import get_settings
from app.database import Base, get_db
from app.main import app


@pytest.fixture
def client_auth_on(monkeypatch: pytest.MonkeyPatch):
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    TestSession = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def _get_db():
        db = TestSession()
        try:
            yield db
        finally:
            db.close()

    monkeypatch.setenv("DISABLE_AUTH", "false")
    monkeypatch.setenv("API_KEY", "secret-test-key")
    get_settings.cache_clear()
    app.dependency_overrides[get_db] = _get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()
    get_settings.cache_clear()


def test_create_without_key_returns_401(client_auth_on: TestClient) -> None:
    r = client_auth_on.post(
        "/api/v1/books/",
        json={
            "title": "No Key",
            "author": "X",
            "genre": "Y",
        },
    )
    assert r.status_code == 401


def test_create_with_key_succeeds(client_auth_on: TestClient) -> None:
    r = client_auth_on.post(
        "/api/v1/books/",
        headers={"X-API-Key": "secret-test-key"},
        json={
            "title": "With Key",
            "author": "Y",
            "genre": "Z",
        },
    )
    assert r.status_code == 201
    assert r.json()["title"] == "With Key"
