Book Library and Analytics API

This project exposes a book catalogue backed by SQL persistence: full CRUD on books and read-only aggregates grouped by genre. All API routes live under /api/v1. Request and response bodies are JSON (UTF-8); use Content-Type: application/json when sending a body. The default local base URL is http://127.0.0.1:8000. Endpoints for the book collection use /api/v1/books/. For a single book, append the numeric id, e.g. /api/v1/books/3 is the row with id 3.

Version: 1.0.0


1. Authentication

Any request that creates, updates, or deletes a book must send the header X-API-Key with the same value as API_KEY in the runtime environment; see .env.example. The three cases are: POST /api/v1/books/ (create), PATCH /api/v1/books/{book_id} (update), DELETE /api/v1/books/{book_id} (delete).

These endpoints are read-only and do not require a key: GET /health, GET /api/v1/books/, GET /api/v1/books/{book_id}, GET /api/v1/analytics/summary.

Set DISABLE_AUTH=true to skip key checks; use only for local debugging, not in production.

A missing or invalid key yields 401 with a detail message in the body and WWW-Authenticate: ApiKey on the response.


2. HTTP status codes

| Code | Meaning |
|--------|------|
| 200 | Success (read or update succeeded) |
| 201 | Created (new book) |
| 204 | No content (delete succeeded, empty body) |
| 401 | Unauthorized |
| 404 | Resource not found (e.g. unknown book id) |
| 422 | Request parameters or JSON failed validation |


3. Example error bodies

On validation failure (422), the body includes a list of field errors in detail plus a fixed code:

{
  "detail": [ ],
  "code": "validation_error"
}

Book not found (404):

{
  "detail": "Book not found"
}

Unauthorized (401):

{
  "detail": "Invalid or missing API key. Send header X-API-Key."
}


4. Book JSON shape

List, single-book fetch, create, and update responses share the same shape (BookRead). The create body (BookCreate) has the same fields except id; title, author, and genre are required, the rest optional. Updates (BookUpdate) are partial: only fields present in the body are written; others stay unchanged.

| Field | Type | Description |
|------|------|------|
| id | integer | Response only; database-generated |
| title | string | Required on create; length 1–500 |
| author | string | Required on create; length 1–300 |
| genre | string | Required on create; length 1–120; list filter matches this column exactly; analytics group by this field |
| publication_year | integer or null | Optional; if set, 1000–2100 |
| rating | number or null | Optional; if set, 0–5 inclusive |
| notes | string or null | Optional |

Create example:

{
  "title": "Example",
  "author": "A. Student",
  "genre": "Fiction",
  "publication_year": 2020,
  "rating": 4.0,
  "notes": null
}


5. Analytics summary JSON (200 body for GET /api/v1/analytics/summary)

| Field | Type | Meaning |
|------|------|------|
| total_books | integer | Number of rows in books |
| genres | array | One entry per distinct genre |
| genres[].genre | string | Genre name |
| genres[].count | integer | Books in that genre |
| genres[].average_rating | number or null | Average rating where ratings exist; null if none |
| average_rating_overall | number or null | Average over all non-null ratings; null if none |


6. Endpoints

GET /health  
No auth. 200 body: { "status": "ok" }

GET /api/v1/books/  
No auth. Query: skip (default 0, ≥0), limit (default 50, 1–100), genre (optional, exact match on genre). On success, status 200 and the body is a JSON array of books; each element is a full record, sorted by id.

GET /api/v1/books/{book_id}  
No auth. On success, status 200 and the body is JSON for the full book with that id; 404 if that id does not exist.

POST /api/v1/books/  
Requires X-API-Key unless DISABLE_AUTH=true. Body: BookCreate. If creation succeeds, the status code is 201, the body is JSON for the complete book record, and the id is assigned by the server.

PATCH /api/v1/books/{book_id}  
Requires X-API-Key unless DISABLE_AUTH=true. Body: BookUpdate. If the update succeeds, status 200 and the body is JSON for that book’s full record after the change; 404 if the id does not exist.

DELETE /api/v1/books/{book_id}  
Requires X-API-Key unless DISABLE_AUTH=true. 204 on success with no body; 404 if missing.

GET /api/v1/analytics/summary  
No auth. 200 returns the summary structure described in section 5.


7. CSV bulk import (not HTTP)

Field validation matches book creation via the API. From the project root run:

python scripts/import_csv.py --replace

By default this reads data/books_gutenberg_catalog_sample.csv. --replace clears the books table before import.


After the service starts you can also use GET /docs (Swagger), GET /redoc, and GET /openapi.json for the machine-readable contract and browser-based trials.
