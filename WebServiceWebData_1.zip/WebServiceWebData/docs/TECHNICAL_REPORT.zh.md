技术报告：图书库与分析 API

作者：待填写
学号：待填写
仓库：待填写公开仓库地址
日期：2026 年 4 月

1. 引言
// 1.0
本项目实现一个以图书目录为核心的 RESTful HTTP 后端：用关系型 SQL 持久化书目字
段，提供 Book 资源的完整 CRUD、按体裁聚合的只读分析，以及健康检查与 OpenAPI 
文档。交互以 JSON 为主，根路径仅提供极简落地页便于打开 Swagger。下文依次说明
架构与关键设计、个人对技术栈的论证、数据与接口要点、安全与数据接入、部署、测试
与经验教训、局限与改进，以及生成式人工智能的声明与使用反思。


// 2.0
本项目是一个围绕图书目录的 RESTful HTTP 后端。书目信息保存在关系型数据库中，客户端主要通过 JSON 与接口交互。在图书数据上，接口支持常见的四类操作，即新增图书记录、按条件或编号查询、修改已有记录、删除记录。这四个操作在下文中合称 CRUD。

除上述日常维护能力外，服务还提供一类统计型接口。接口按每条书记录上的题材字段genre分组，汇总各题材下有多少册书、各题材的平均评分等。这类接口只供查询结果，不能在接口里直接改写统计数字，数字由后台根据当前表内数据实时计算。另设有一个简单的小接口，用于快速回答服务是否已启动并能响应请求这一类问题。这个接口返回内容简单，一般不访问业务表，便于部署与探活脚本使用。项目根路径提供简短网页，方便在浏览器中打开 Swagger。项目还提供 OpenAPI 相关文档路径。

2. 架构与关键设计选择

整体采用经典三层思路。客户端通过 HTTP 访问 FastAPI 路由；应用层通过依赖注入获取数据库会话并调用CRUD。持久层由 SQLAlchemy Session 与 SQLite 或其他 DATABASE_URL 指向的引擎承担。应用层的路由按功能拆分为 books 与 analytics 两个 APIRouter，在 main 中统一挂载到 /api/v1，便于未来在不破坏旧客户端的前提下改进接口。

模块划分上，main.py 负责应用生命周期与全局异常处理。config.py 集中 Settings。database.py 提供引擎、会话工厂与 get_db()。models.py 负责数据库表映射，schemas.py 负责 API 请求和响应的 JSON 校验与结构。crud.py 保持与 FastAPI 无关，便于单独测试。deps.py 将鉴权与数据库依赖封装为可复用的 Annotated 别名。/app/routers 仅编排 HTTP 语义。这种划分降低耦合，便于维护。

请求路径上，读操作通过get_db() 注入会话后查询 ORM，结果序列化为 BookRead；统计类分析接口亦为只读，无需 API Key，聚合逻辑在 crud 模块内的 analytics_summary() 完成。写操作在启用鉴权时先执行 verify_api_key()，再按 BookCreate 或 BookUpdate 校验请求体并提交事务。统一注册 RequestValidationError 处理器，凡请求参数或 JSON 未通过校验，返回带 code 的 JSON，与业务上的 404 区分。

在接口风格上，本项目主要围绕图书这一个资源进行只读的统计，未出现多实体图遍历或客户端任意裁剪字段的需求，因此采用 REST 与 OpenAPI 优先，而非引入 GraphQL。

3. 技术栈论证：编程语言、框架与数据库

3.1 编程语言：Python 3

选择 Python 是基于以下理由。第一，本项目需要快速迭代与可读源码，Python 语法与生态对这种小型服务足够。第二，FastAPI、SQLAlchemy、Pydantic 与 pytest 在同一语言栈内衔接顺畅，减少跨语言边界。第三，使用 Python 的类型标注，并结合 typing_extensions.Annotated 标注依赖与参数，在 IDE 里可以清楚看到路由与注入关系。这样既保留 Python 快速开发的长处，又能靠类型信息提高可读性和后续维护的便利性。

3.2 应用框架与契约层：FastAPI、Pydantic、Uvicorn

选用 FastAPI 的重要原因之一，是在实现 REST 接口的同时，由框架根据路由与依赖的类型注解生成 OpenAPI，并暴露 /docs、/redoc 等页面，从而减少单独维护文档的负担，也降低文档与实现不一致的风险。Pydantic v2 负责请求体、响应体与 settings，使 BookCreate 与表字段长度对齐，从入口上减少无效写入。pydantic-settings 将 DATABASE_URL、API_KEY、DISABLE_AUTH 外置到 .env，符合十二因子中配置与代码分离的习惯。

本地开发时用 Uvicorn 启动应用，常用命令为：uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
这样，保存代码后会自动重载；若不需要热重载，可去掉命令里的 --reload。
依赖文件 requirements.txt 里只写最基础的 uvicorn，这是因为在 Windows 的uvicorn可选库常常没有现成安装包，pip 会尝试在本机从源码编译，若电脑未安装 Visual C++ 等编译环境就容易报错失败。

3.3 持久化与数据库：SQLAlchemy 2.x 与 SQLite 为默认

选用 SQLAlchemy 2.x 作为 Object-Relational Mapping。用声明式模型描述表结构，select() 用于查询。图书的增删改与分析接口背后的查询在同一次数据库会话中完成，分组、计数、求平均等在数据库里执行，不把整张表读进 Python 再统计。

数据库层面，使用 SQLite数据库，项目中的数据库文件 books.db，无独立数据库进程。连接串通过 DATABASE_URL 外置，切换至 PostgreSQL 等时，业务 SQL 多数可由 SQLAlchemy 承载。这种设计优先降低运维与部署门槛，接受 SQLite 在并发写与锁粒度上的已知限制；当读多写少、并发可控时足够，若写入并发或数据量显著上升，应迁移到服务器型数据库并引入连接池与正式迁移工具。系统现在使用 create_all() 建表，而未引入 Alembic。不过如果以后长期生产、表结构经常变化，就应该引用 Alembic 做正式迁移。

测试栈选用 pytest 与 Starlette TestClient，配合内存 SQLite 与 dependency_overrides 隔离开发机上的 books.db，保证回归可重复。httpx 随测试依赖引入。

4. 数据模型与接口语义要点

4.1 表结构与字段

数据库表名为 books，ORM 映射类为 app.models.Book。表结构由 SQLAlchemy 声明式模型定义，接口请求与响应由 Pydantic 的 BookCreate、BookUpdate、BookRead 校验。

字符串列在 API 侧使用最小长度与最大长度约束，与库中 VARCHAR 宽度一致。允许为空的列在数据库中为 NULL，对应 JSON 中可省略该字段或显式传 null。评分 rating 可选，在分析接口中计算平均评分时使用 SQL 的 AVG函数，且 NULL 行不参与求平均。

表 books 列定义与契约对应关系如下。

| 列名 | SQL 类型 | 约束与索引 | API 与校验要点 |
|------|----------|------------|----------------|
| id | INTEGER | 主键，自增；ORM 上带 index | 仅出现在 BookRead；由数据库生成，POST 请求体不包含 |
| title | VARCHAR(500) | NOT NULL，索引 | 必填，长度 1～500；列表与展示主字段 |
| author | VARCHAR(300) | NOT NULL，索引 | 必填，长度 1～300 |
| genre | VARCHAR(120) | NOT NULL，索引 | 必填，长度 1～120；列表可按 genre 精确筛选；分析接口按该列 group_by() |
| publication_year | INTEGER | 可空 | 可选，校验范围 1000～2100；不参与当前聚合 SQL |
| rating | FLOAT | 可空 | 可选，0～5 闭区间；聚合时 AVG 排除 NULL |
| notes | TEXT | 可空 | 可选，无最大长度约束于 Pydantic，长文本备注 |

主键 id 用于 REST 路径 /api/v1/books/{id}，列表默认按 id 排序。title、author、genre 三列在库中建索引，支撑按体裁过滤与高频列表读取。作者与体裁以字符串形式与同一条图书记录一起存放，而不拆成独立的作者表、体裁表，是为了降低 CRUD 与 CSV 批量导入的实现与数据准备成本。分析接口按 genre 做精确匹配与分组，若同一体裁出现多种表达方式，会被统计成不同组，这是为简化模型有意接受的取舍。评分区间、出版年份范围等规则由 Pydantic 在 API 层校验。若绕过接口直接改库，可能写入不符合业务假设的数据。

4.2 REST 选择与语义

本项目主要实现两个功能：一是围绕图书这一种资源提供增删改查，二是提供按体裁汇总的只读统计。表与表之间没有复杂关联，也不需要在一次请求里跨多种资源任意组合查询，因此采用常见的 REST 接口，并由 FastAPI 自动生成 OpenAPI，便于在 Swagger 里试调与核对契约。未采用 GraphQL，避免为当前较小的数据规模额外维护一套查询解析与类型定义。

在常用 HTTP 语义上，多次相同的 GET 或 DELETE 不会改变目标资源以外的数据。删除不存在的图书 id 时返回 404，不会影响其他行。新建图书时，每次成功提交都会在库里增加一行。局部更新使用 PATCH，这意味着请求体里写了哪些字段就更新哪些列，未写到的字段保持原值，因此这种设计适合进行少量字段的改动。

4.3 分页、筛选与状态码

列表 GET /api/v1/books/ 使用 skip、limit 与可选 genre 精确匹配，limit 上限 100，crud 中按 id 排序以保证稳定顺序；实现为 offset 分页，深翻页或高并发写入下可考虑游标分页，与第 8 节改进方向一致。HTTP 状态码包括 200、201、204、401、404、422；全局校验失败响应附加 validation_error，便于与 404 区分。

5. 安全、配置与数据接入

变更类接口使用共享密钥式的 X-API-Key，与 API_KEY 环境变量比对；可通过 DISABLE_AUTH 在测试环境关闭。该模型适合演示与单团队场景，不提供多租户与吊销能力。密钥仅存在于 .env，仓库提供 .env.example。公网部署应在平台侧终结 HTTPS。

// 2.0
CSV 导入通过 scripts/import_csv.py 执行，默认数据文件为 data/books_gutenberg_catalog_sample.csv。该文件由 scripts/build_gutenberg_csv.py 从 Project Gutenberg 官方目录 CSV 筛选生成，与 HTTP 共用 BookCreate 与 create_book()，保证批量与接口规则一致。

*English.* CSV import is run with scripts/import_csv.py. The default dataset is data/books_gutenberg_catalog_sample.csv, built by scripts/build_gutenberg_csv.py by filtering Project Gutenberg’s official catalogue CSV. The script shares BookCreate and create_book() with the HTTP layer so bulk loading follows the same validation rules as the API.

6. 部署与运维

本地启动命令为 uvicorn app.main:app --host 127.0.0.1 --port 8000，生产建议使用进程管理器。托管时需配置 ASGI 入口、环境变量与持久化 DATABASE_URL。当前未接入集中式日志与指标，排错依赖控制台与开发模式异常栈；生产可补充请求 ID 与健康监控。

7. 测试方法、挑战与经验教训

7.1 测试方法与覆盖范围

测试分为 test_api.py 与 test_auth.py：前者覆盖健康检查、CRUD 全流程、分析 JSON 形状、校验封装、字段长度与数值边界、genre 筛选与 limit 越界；后者在单独 fixture 中开启鉴权，验证无 Key 返回 401、正确 Key 可创建。conftest 使用内存 SQLite、StaticPool、覆盖 get_db()，并在前后清理 dependency_overrides 与 get_settings() 缓存，避免测试污染本地 books.db 或相互干扰。

未纳入本仓库的包括压力测试、模糊测试、安全渗透与多进程下 SQLite 竞态专项；高流量上线前应另建计划。

7.2 开发中遇到的挑战与应对

第一，pydantic-settings 会用缓存避免重复读取配置，仅修改环境变量时，若测试里不调用 cache_clear()，仍会得到旧的 Settings。所以在 conftest 的 teardown 中显式清理该缓存。

第二， uvicorn的设计，详见3.2 节。

第三，边界与 Query 测试、Swagger 联调，详见7.1 节、4.2 节。

7.3 经验教训

第一，数据库读写集中在 CRUD 模块，路由里只做参数与 HTTP 语义，这样集成测试走到的路径与真实请求一致，日后若补充更细致的单元测试，也可以继续复用 CRUD 模块中的同一套规则。CSV 导入脚本调用与接口相同的 create_book()，避免导入和接口的规则不一致。

第二，OpenAPI 作为整个项目的设计和实现的标准原则。

第三，测试里用 FastAPI 的依赖覆盖，在不大改架构的前提下就能换用内存库、隔离环境，在当前的项目规模下是成本与收益最平衡的做法。

8. 局限性与未来发展的潜在改进

授权与身份仍停留在全局 API Key，后续可引入 OAuth2 或按客户端密钥入库与吊销。数据库在写并发与数据量增长时需迁移 PostgreSQL 并配合连接池、备份与 Alembic 类迁移。分析接口可从事后实时聚合走向物化视图或缓存。分页可从 offset 演进为游标；检索可从 genre 精确匹配扩展为全文或专用搜索引擎。多实体域模型成熟时可再评估 GraphQL 或 MCP 等暴露方式。可观测性需从控制台日志走向结构化日志与告警。

9. 生成式人工智能：声明与使用分析

9.1 合规声明与工具记录

若课程或单位要求申报生成式 AI 使用，须如实填写所用工具、用途，并按要求保留对话摘录。个人确认下表信息真实。工具是否用于代码、文档或调试等以「是 / 否 / 部分」标注；「部分」表示偶有涉及但非主用途。

| 工具名称 | 主要用途类别 | 代码 | 文档 | 调试 |
|----------|--------------|------|------|------|
| Cursor（Composer，IDE 内嵌助手） | 实现与完善项目：功能开发、重构、测试与运行问题排查、依赖与环境相关修改 | 是 | 部分 | 是 |
| DeepSeek | 中英互译、技术报告等文档表述整理 | 否 | 是 | 否 |

// 2
**English.** If your course or organisation requires declaring generative AI use, list tools and purposes truthfully and retain conversation excerpts as required. I confirm the table below is accurate. Use of each tool for code, documentation, or debugging is marked Yes / No / Partial; Partial means occasional involvement but not the primary role.

| Tool | Primary use | Code | Documentation | Debugging |
|------|-------------|------|-----------------|-----------|
| Cursor (Composer, IDE-embedded assistant) | Implementing and refining the project: feature development, refactoring, tests and runtime troubleshooting, dependency- and environment-related edits | Yes | Partial | Yes |
| DeepSeek | Chinese–English translation and polishing technical report wording | No | Yes | No |

9.2 对使用方式的审慎分析

Cursor主要是修改后端代码与测试，排查运行与依赖问题。DeepSeek主要是进行项目报告的书写完善和中英文翻译。本人仍负责在本地跑 pytest、对照 OpenAPI 与仓库实际行为并进行分析判断。
当前，GenAI适合加速实现与改稿，但可能会导致一些细节问题或者与项目设计不一样的实现。因此要以设计文档作为标准、逐步分析采纳并自行验证，而不是接受ai的所有内容。

9.3 个人反思待填写

待填写：实际使用的工具；请求其完成的具体任务；本人完成的验证步骤；观察到的生成内容局限或一次纠正经历。

10. 结论

本项目以清晰分层与显式契约为核心，在 Python、FastAPI、SQLAlchemy 与默认 SQLite 的组合下交付可测试的图书库 API，并通过技术栈论证说明了语言、框架与数据库选择的个人取舍。测试与依赖注入实践支撑了迭代与回归；局限与改进方向已在第 8 节归纳。生成式 AI 应在声明前提下审慎使用，以本地验证与学术诚信为约束。

参考文献

1. FastAPI Documentation. https://fastapi.tiangolo.com/
2. Pydantic Documentation. https://docs.pydantic.dev/
3. SQLAlchemy Documentation. https://docs.sqlalchemy.org/
4. Fielding, R. T. 于 2000 年发表博士论文 Architectural Styles and the Design of Network-based Software Architectures，UC Irvine。
5. Richardson, L., & Ruby, S. 于 2013 年出版 RESTful Web APIs，O'Reilly。
6. Open Library. https://openlibrary.org/
7. DeepSeek（深度求索）. 本报告中文与英文表述的翻译及润色。https://www.deepseek.com/

报告结束。
